package play.modules.httpmock;

import play.libs.ws.WSAsync;

public class WSMock extends WSAsync {
    // TODO
}
